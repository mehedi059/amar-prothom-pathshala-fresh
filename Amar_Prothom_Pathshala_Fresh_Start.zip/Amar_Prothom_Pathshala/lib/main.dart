import 'dart:convert';
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/services.dart';
import 'package:material_ui/material_ui.dart';

void main() => runApp(const AmarProthomPathshalaApp());

class AmarProthomPathshalaApp extends StatelessWidget {
  const AmarProthomPathshalaApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'আমার প্রথম পাঠশালা', debugShowCheckedModeBanner: false,
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF168A62)), useMaterial3: true),
    home: const HomePage(),
  );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final AudioPlayer _player = AudioPlayer();
  Map<String, dynamic> _data = {};
  String _tab = 'bn';
  bool _loading = true;
  String? _playing;

  @override
  void initState() { super.initState(); _load(); }
  Future<void> _load() async {
    final raw = await rootBundle.loadString('assets/data/lessons.json');
    if (!mounted) return;
    setState(() { _data = jsonDecode(raw) as Map<String, dynamic>; _loading = false; });
  }
  Future<void> _play(String path, String key) async {
    try {
      setState(() => _playing = key);
      await _player.stop();
      await _player.play(AssetSource(path));
      _player.onPlayerComplete.listen((_) { if (mounted) setState(() => _playing = null); });
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('অডিও পাওয়া যায়নি। Build-এর আগে Generate Audio ধাপ সফল হয়েছে কি না দেখুন।')));
    }
  }
  @override
  void dispose() { _player.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    final lessons = (_data['lessons'] as List).cast<Map<String, dynamic>>();
    final selected = lessons.where((e) => e['language'] == _tab).toList();
    final rhymes = (_data['rhymes'] as List).cast<Map<String, dynamic>>();
    return Scaffold(
      appBar: AppBar(title: const Text('আমার প্রথম পাঠশালা', style: TextStyle(fontWeight: FontWeight.bold)), centerTitle: true),
      body: Column(children: [
        Padding(padding: const EdgeInsets.all(12), child: Text('খেলতে খেলতে শিখি', style: Theme.of(context).textTheme.titleLarge)),
        Padding(padding: const EdgeInsets.symmetric(horizontal: 10), child: SegmentedButton<String>(
          segments: const [ButtonSegment(value:'bn',label:Text('বাংলা')),ButtonSegment(value:'en',label:Text('English')),ButtonSegment(value:'ar',label:Text('আরবি'))],
          selected: {_tab}, onSelectionChanged: (v) => setState(() => _tab = v.first),
        )),
        Expanded(child: GridView.builder(padding: const EdgeInsets.all(12), gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, crossAxisSpacing: 10, mainAxisSpacing: 10, childAspectRatio: .92), itemCount: selected.length,
          itemBuilder: (context, i) { final item=selected[i]; final key='${item['language']}_${item['audio']}'; final active=_playing==key; return Card(clipBehavior: Clip.antiAlias, child: InkWell(onTap: () => _play('audio/${item['language']}/${item['audio']}',key), child: Padding(padding: const EdgeInsets.all(8), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Text(item['letter'] as String, style: TextStyle(fontSize: _tab=='ar'?38:34,fontWeight:FontWeight.bold,color:active?Colors.white:const Color(0xFF167D5B))), const SizedBox(height:5), Text(item['word'] as String,maxLines:1,overflow:TextOverflow.ellipsis,style: const TextStyle(fontSize:13)), const SizedBox(height:5), Icon(active?Icons.volume_up:Icons.play_circle_fill,color:active?Colors.green:Colors.blueGrey)])))); },
        )),
        SizedBox(height: 112, child: Column(children: [const Divider(height:1), const Text('ছড়া শুনি',style:TextStyle(fontWeight:FontWeight.bold)), Expanded(child: ListView.builder(scrollDirection:Axis.horizontal,itemCount:rhymes.length,itemBuilder:(context,i){final r=rhymes[i];return Padding(padding:const EdgeInsets.symmetric(horizontal:5,vertical:4),child:OutlinedButton.icon(onPressed:()=>_play('audio/rhymes/${r['audio']}','r_${r['audio']}'),icon:const Icon(Icons.music_note),label:Text(r['title'] as String)));}))])),
        Padding(padding: const EdgeInsets.only(bottom:8), child: Text('ডেভেলপার: মো: মেহেদী হাসান', style: Theme.of(context).textTheme.bodySmall)),
      ]),
    );
  }
}
