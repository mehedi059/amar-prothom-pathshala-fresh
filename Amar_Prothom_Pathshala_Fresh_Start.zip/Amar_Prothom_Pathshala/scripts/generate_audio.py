import asyncio, json
from pathlib import Path
import edge_tts

ROOT=Path(__file__).resolve().parents[1]
DATA=json.loads((ROOT/'assets/data/lessons.json').read_text(encoding='utf-8'))
items=[]
for x in DATA['lessons']:
    items.append((x['spoken_text'],x['voice'],ROOT/'assets/audio'/x['language']/x['audio']))
for x in DATA['rhymes']:
    items.append((x['spoken_text'],x['voice'],ROOT/'assets/audio/rhymes'/x['audio']))

async def make(text, voice, path):
    path.parent.mkdir(parents=True,exist_ok=True)
    if path.exists() and path.stat().st_size>1000: return
    last=None
    for attempt in range(1,6):
        try:
            await edge_tts.Communicate(text,voice).save(str(path))
            if path.exists() and path.stat().st_size>1000: return
            raise RuntimeError('MP3 ফাইল তৈরি হলেও আকার খুব ছোট')
        except Exception as e:
            last=e
            print(f'  retry {attempt}/5: {e}',flush=True)
            await asyncio.sleep(attempt*3)
    raise RuntimeError(f'অডিও তৈরি ব্যর্থ: {path.name}: {last}')

async def main():
    for i,(text,voice,path) in enumerate(items,1):
        print(f'[{i}/{len(items)}] {path.relative_to(ROOT)} ({voice})',flush=True)
        await make(text,voice,path)
    print(f'SUCCESS: {len(items)} audio files generated.',flush=True)

if __name__=='__main__': asyncio.run(main())
