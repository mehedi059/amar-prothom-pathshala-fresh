import json, sys, zipfile
from pathlib import Path
root=Path(__file__).resolve().parents[1]
data=json.loads((root/'assets/data/lessons.json').read_text(encoding='utf-8'))
files=[root/'assets/audio'/x['language']/x['audio'] for x in data['lessons']]
files += [root/'assets/audio/rhymes'/x['audio'] for x in data['rhymes']]
missing=[p for p in files if not p.is_file() or p.stat().st_size<=1000]
print(f'Expected: {len(files)}; Missing/invalid: {len(missing)}')
if missing:
    print('\n'.join(str(p.relative_to(root)) for p in missing)); sys.exit(1)
apk=Path(sys.argv[1]) if len(sys.argv)>1 else None
if apk:
    with zipfile.ZipFile(apk) as z:
        names=z.namelist()
        absent=[p.relative_to(root).as_posix() for p in files if not any(n.endswith(p.name) for n in names)]
    if absent: print('Not found inside APK:',*absent,sep='\n'); sys.exit(1)
    print('All audio assets are present inside APK.')
