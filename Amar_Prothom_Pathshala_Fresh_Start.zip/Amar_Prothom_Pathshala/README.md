# আমার প্রথম পাঠশালা

শিশুদের জন্য অফলাইন বাংলা, ইংরেজি ও আরবি বর্ণ শেখার Flutter অ্যাপ।

- Developer: মো: মেহেদী হাসান
- 3-column letter grid; tap to play bundled audio
- 109 generated speech assets (50 Bangla + 26 English + 28 Arabic + 5 rhymes)
- GitHub Actions builds a release APK and uploads it as an artifact

## শুরু থেকে GitHub-এ আপলোড (মোবাইল থেকেও করা যাবে)

1. ZIP ফাইলটি ফোনে Download করে Extract করুন।
2. GitHub-এ লগইন করে `https://github.com/new` খুলুন। Repository name লিখুন `amar-prothom-pathshala`; Public বা Private যেকোনোটি; **Add a README file** টিক দেবেন না; Create repository চাপুন। (আগের একই নামে repo থাকলে নতুন repo করবেন না; সেটির Settings > Danger Zone থেকে নতুন করে শুরু করতে চাইলে Delete করে আবার তৈরি করতে পারেন, তবে পুরোনো কোড দরকার না হলে তবেই।)
3. নতুন repository খুলে **Add file > Upload files** চাপুন। ZIP নয়—Extract করা ফোল্ডারের ভেতরের সব ফাইল ও ফোল্ডার নির্বাচন করে আপলোড করুন। `.github` hidden folder-টি অবশ্যই অন্তর্ভুক্ত করুন।
4. Commit changes চাপুন।
5. repository-র **Actions** ট্যাব খুলুন। বাম পাশে `Build Amar Prothom Pathshala APK` নির্বাচন করুন। `Run workflow` > branch `main` > `Run workflow` চাপুন।
6. Build চলবে। সবুজ টিক হলে workflow run খুলে নিচের **Artifacts** অংশ থেকে `amar-prothom-pathshala-apk` ডাউনলোড করুন। ZIP artifact Extract করলে `app-release.apk` পাবেন।
7. APK ফোনে Install করুন। প্রথমবার Android unknown-app install permission চাইলে শুধু নিজের ডাউনলোড করা APK-এর জন্য অনুমতি দিন।

## জরুরি

- প্রথম build-এ Actions internet ব্যবহার করে Microsoft Edge neural voices তৈরি করে। তৈরি MP3 ফাইলগুলো APK-তে ঢোকে, তাই ইনস্টল হওয়ার পর পাঠ/ছড়া শুনতে ইন্টারনেট লাগে না।
- কণ্ঠ: বাংলা বাংলাদেশি `Pradeep` (পুরুষ) ও `Nabanita` (নারী), ইংরেজি `Guy`/`Jenny`, আরবি `Hamed`/`Zariyah`। Microsoft-এর Edge TTS endpoint অনানুষ্ঠানিক; 403/সার্ভার সীমাবদ্ধতা হলে voice generation ধাপ ব্যর্থ হতে পারে। 7.3.0-এ আপডেট করা হয়েছে, কিন্তু endpoint-এর প্রাপ্যতা নিশ্চিত করা যায় না।
- এই ZIP-এ আগে থেকে তৈরি MP3 নেই; GitHub Actions-এ সফলভাবে generate ও verify হওয়ার পরই APK তৈরি হবে।
- এই সংস্করণে অক্ষরের কার্ডে emoji/লেখা-ভিত্তিক UI আছে; বাস্তব ছবির পূর্ণ লাইব্রেরি এখনো যুক্ত নয়।
- Local machine-এ Flutter SDK ছাড়া এখানে APK build করা হয়নি। GitHub Actions-ই build/analyze-এর চূড়ান্ত যাচাই করবে।

## License
MIT — see `LICENSE`.
